/**
 * Created by lilit on 6/7/17.
 */
var AWS = require('aws-sdk');


exports.invalidationFinished = (event, context, callback) => {

	console.log("Finished....")
}