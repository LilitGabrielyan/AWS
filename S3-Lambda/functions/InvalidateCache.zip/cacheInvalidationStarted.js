/**
 * Created by lilit on 6/7/17.
 */
var AWS = require('aws-sdk');


exports.invalidationStarted = (event, context, callback) => {

	console.log("Started....")
}